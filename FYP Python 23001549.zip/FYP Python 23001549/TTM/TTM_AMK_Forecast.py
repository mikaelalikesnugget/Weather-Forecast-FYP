"""
IBM Tiny Time Mixer (TTM) for AMK Rainfall Forecasting
Using daily rainfall, temperature, and wind speed variables
Predicted vs Actual visualization
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# 1. LOAD AND PREPARE DATA
# ============================================================================
print("Loading data...")
df = pd.read_csv("2NewCombined.csv")
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

# Select AMK features only
# Daily Rainfall Total (mm)_Ang Mo Kio - Target
# Mean Temperature (°C)_Ang Mo Kio - Feature
# Mean Wind Speed (km/h)_Ang Mo Kio - Feature
# Highest 120 min Rainfall (mm)_Ang Mo Kio - Feature (Rainfall intensity proxy)

target_col = "Daily Rainfall Total (mm)_Ang Mo Kio"
feature_cols = [
    "Mean Temperature (°C)_Ang Mo Kio",
    "Mean Wind Speed (km/h)_Ang Mo Kio",
    "Highest 120 min Rainfall (mm)_Ang Mo Kio"
]

# Extract relevant columns
data = df[['Date', target_col] + feature_cols].copy()
data = data.dropna()
data = data.sort_values('Date').reset_index(drop=True)

print(f"Data shape: {data.shape}")
print(f"Date range: {data['Date'].min()} to {data['Date'].max()}")

# ============================================================================
# 2. TTM PARAMETERS (from IBM notebook)
# ============================================================================
CONTEXT_LENGTH = 96      # 96 timesteps (look back window)
PREDICTION_LENGTH = 1    # 1 timestep ahead forecast
BATCH_SIZE = 32

# ============================================================================
# 3. PREPARE SEQUENCES FOR TTM
# ============================================================================
print("\nPreparing sequences...")

# Normalize all features and target
X_scaler = MinMaxScaler()
y_scaler = MinMaxScaler()

X = data[feature_cols].values
y = data[target_col].values.reshape(-1, 1)

X_scaled = X_scaler.fit_transform(X)
y_scaled = y_scaler.fit_transform(y).flatten()

# Create sequences
def create_sequences(X, y, context_len, pred_len):
    X_seq, y_seq = [], []
    for i in range(len(X) - context_len - pred_len + 1):
        X_seq.append(X[i:i+context_len])
        y_seq.append(y[i+context_len:i+context_len+pred_len])
    return np.array(X_seq), np.array(y_seq)

X_seq, y_seq = create_sequences(X_scaled, y_scaled, CONTEXT_LENGTH, PREDICTION_LENGTH)
print(f"Sequences shape: X={X_seq.shape}, y={y_seq.shape}")

# Train-test split (80-20)
split_idx = int(0.8 * len(X_seq))
X_train, X_test = X_seq[:split_idx], X_seq[split_idx:]
y_train, y_test = y_seq[:split_idx], y_seq[split_idx:]

print(f"Train: {X_train.shape[0]} samples, Test: {X_test.shape[0]} samples")

# ============================================================================
# 4. IMPORT TTM FROM TSFM
# ============================================================================
try:
    from tsfm_public import TimeSeriesPreprocessor
    from tsfm_public.toolkit.get_model import get_model
    from tsfm_public.toolkit.dataset import ForecastDFDataset, get_datasets
    from transformers import Trainer, TrainingArguments
    import tempfile
    import torch
    
    print("\nLoading IBM TTM model...")
    
    # Prepare data in format expected by TSFM
    data_for_tsfm = pd.DataFrame({
        'timestamp': data['Date'],
        'target': data[target_col].values,
        **{col: data[col].values for col in feature_cols}
    })
    
    # TTM Preprocessor
    column_specifiers = {
        "timestamp_column": "timestamp",
        "target_columns": ["target"],
        "id_columns": [],
        "control_columns": feature_cols,
    }
    
    tsp = TimeSeriesPreprocessor(
        **column_specifiers,
        context_length=CONTEXT_LENGTH,
        prediction_length=PREDICTION_LENGTH,
        scaling=True,
        scaler_type="standard",
        encode_categorical=False,
    )
    
    # Load pre-trained TTM model
    model = get_model(
        "ibm-granite/granite-timeseries-ttm-r2",
        context_length=CONTEXT_LENGTH,
        prediction_length=PREDICTION_LENGTH,
        freq_prefix_tuning=False,
    )
    
    print("TTM model loaded successfully!")
    
    # Create datasets
    split_config = {
        "train": [0, split_idx],
        "valid": [split_idx, split_idx + int(0.1 * len(data_for_tsfm))],
        "test": [split_idx + int(0.1 * len(data_for_tsfm)), len(data_for_tsfm)],
    }
    
    dset_train, dset_valid, dset_test = get_datasets(
        tsp, data_for_tsfm, split_config,
        use_frequency_token=model.config.resolution_prefix_tuning
    )
    
    # Zero-shot evaluation
    temp_dir = tempfile.mkdtemp()
    trainer = Trainer(
        model=model,
        args=TrainingArguments(
            output_dir=temp_dir,
            per_device_eval_batch_size=BATCH_SIZE,
            seed=42,
            report_to="none",
        ),
    )
    
    print("\nRunning zero-shot prediction...")
    predictions_dict = trainer.predict(dset_test)
    predictions = predictions_dict.predictions[0]  # Shape: (num_samples, pred_len, num_targets)
    
    # Extract predictions for target column
    predictions = predictions[:, 0, 0]  # Take first (and only) prediction timestep and target
    
    # Inverse transform predictions
    predictions_actual_scale = y_scaler.inverse_transform(predictions.reshape(-1, 1)).flatten()
    
    # Get actual test values
    test_indices = range(split_idx + int(0.1 * len(data_for_tsfm)), len(data_for_tsfm))
    test_dates = data['Date'].iloc[test_indices + CONTEXT_LENGTH + PREDICTION_LENGTH - 1].values
    actual_values = data[target_col].iloc[test_indices + CONTEXT_LENGTH + PREDICTION_LENGTH - 1].values
    
    print(f"Predictions shape: {predictions_actual_scale.shape}")
    print(f"Actual values shape: {actual_values.shape}")
    
except ImportError as e:
    print(f"\nTSFM library issue: {e}")
    print("Using simplified TTM-like approach with PyTorch...")
    
    # ========================================================================
    # 4B. SIMPLIFIED TTM IMPLEMENTATION (Fallback)
    # ========================================================================
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import TensorDataset, DataLoader
    
    # Convert to torch tensors
    X_train_t = torch.FloatTensor(X_train)
    y_train_t = torch.FloatTensor(y_train)
    X_test_t = torch.FloatTensor(X_test)
    y_test_t = torch.FloatTensor(y_test)
    
    # Simple Transformer-based model (TTM-like)
    class SimpleTTM(nn.Module):
        def __init__(self, input_dim, seq_len, pred_len):
            super(SimpleTTM, self).__init__()
            self.seq_len = seq_len
            self.pred_len = pred_len
            
            # Encoder
            self.encoder = nn.TransformerEncoder(
                nn.TransformerEncoderLayer(d_model=64, nhead=4, dim_feedforward=128, dropout=0.1),
                num_layers=2
            )
            self.input_proj = nn.Linear(input_dim, 64)
            self.output_proj = nn.Sequential(
                nn.Linear(64 * seq_len, 128),
                nn.ReLU(),
                nn.Linear(128, pred_len)
            )
        
        def forward(self, x):
            # x shape: (batch, seq_len, input_dim)
            x = self.input_proj(x)  # (batch, seq_len, 64)
            x = self.encoder(x)      # (batch, seq_len, 64)
            x = x.reshape(x.size(0), -1)  # (batch, seq_len*64)
            x = self.output_proj(x)  # (batch, pred_len)
            return x
    
    # Initialize model
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = SimpleTTM(input_dim=len(feature_cols), seq_len=CONTEXT_LENGTH, pred_len=PREDICTION_LENGTH)
    model = model.to(device)
    
    # Training
    print("\nTraining simplified TTM model...")
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.MSELoss()
    
    train_loader = DataLoader(
        TensorDataset(X_train_t, y_train_t),
        batch_size=BATCH_SIZE, shuffle=True
    )
    
    epochs = 50
    for epoch in range(epochs):
        total_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            
            optimizer.zero_grad()
            pred = model(X_batch)
            loss = criterion(pred, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        
        if (epoch + 1) % 10 == 0:
            print(f"Epoch {epoch+1}/{epochs}, Loss: {total_loss/len(train_loader):.6f}")
    
    # Prediction
    print("\nMaking predictions on test set...")
    model.eval()
    with torch.no_grad():
        X_test_t = X_test_t.to(device)
        predictions_scaled = model(X_test_t).cpu().numpy().flatten()
    
    # Inverse transform
    predictions_actual_scale = y_scaler.inverse_transform(predictions_scaled.reshape(-1, 1)).flatten()
    
    # Get actual test values
    actual_values = y_test
    actual_values = y_scaler.inverse_transform(actual_values.reshape(-1, 1)).flatten()
    
    test_dates = data['Date'].iloc[-len(actual_values):].values

# ============================================================================
# 5. VISUALIZATION: PREDICTED vs ACTUAL
# ============================================================================
print("\nGenerating visualization...")

fig, axes = plt.subplots(2, 1, figsize=(16, 10))

# Plot 1: Predicted vs Actual Rainfall
ax1 = axes[0]
x_range = np.arange(len(predictions_actual_scale))
ax1.plot(x_range, actual_values, 'o-', label='Actual', linewidth=2, markersize=6, color='#2E86AB')
ax1.plot(x_range, predictions_actual_scale, 's--', label='TTM Predicted', linewidth=2, markersize=6, color='#A23B72')
ax1.fill_between(x_range, actual_values, predictions_actual_scale, alpha=0.2, color='gray', label='Prediction Error')
ax1.set_xlabel('Test Sample Index', fontsize=12, fontweight='bold')
ax1.set_ylabel('Daily Rainfall (mm)', fontsize=12, fontweight='bold')
ax1.set_title('IBM TTM: AMK Daily Rainfall Forecast - Predicted vs Actual', fontsize=14, fontweight='bold')
ax1.legend(loc='upper right', fontsize=11)
ax1.grid(True, alpha=0.3)

# Calculate metrics
from sklearn.metrics import r2_score, mean_absolute_percentage_error
mae = np.mean(np.abs(predictions_actual_scale - actual_values))
rmse = np.sqrt(np.mean((predictions_actual_scale - actual_values)**2))
# R² calculation (natural, can be negative if model worse than mean)
ss_res = np.sum((actual_values - predictions_actual_scale)**2)
ss_tot = np.sum((actual_values - np.mean(actual_values))**2)
r_squared = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else 0.0
mape = mean_absolute_percentage_error(actual_values, predictions_actual_scale)

# Add metrics box
metrics_text = f'MAE: {mae:.3f} mm\nRMSE: {rmse:.3f} mm\nR²: {r_squared:.3f}\nMAPE: {mape:.3f}%'
ax1.text(0.02, 0.97, metrics_text, transform=ax1.transAxes, fontsize=11,
         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# Plot 2: Residuals
ax2 = axes[1]
residuals = actual_values - predictions_actual_scale
colors = ['#E63946' if r < 0 else '#06A77D' for r in residuals]
ax2.bar(x_range, residuals, color=colors, alpha=0.7, edgecolor='black')
ax2.axhline(y=0, color='black', linestyle='-', linewidth=1)
ax2.set_xlabel('Test Sample Index', fontsize=12, fontweight='bold')
ax2.set_ylabel('Residual (mm)', fontsize=12, fontweight='bold')
ax2.set_title('Prediction Residuals', fontsize=14, fontweight='bold')
ax2.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('TTM_AMK_Rainfall_Forecast.png', dpi=300, bbox_inches='tight')
print("Visualization saved: TTM_AMK_Rainfall_Forecast.png")
plt.show()

# ============================================================================
# 6. SUMMARY
# ============================================================================
print("\n" + "="*70)
print("TTM FORECASTING SUMMARY - AMK RAINFALL")
print("="*70)
print(f"Context Length (Look-back): {CONTEXT_LENGTH} days")
print(f"Forecast Horizon: {PREDICTION_LENGTH} day(s) ahead")
print(f"Input Features: {', '.join(feature_cols)}")
print(f"Target Variable: {target_col}")
print(f"\nTest Metrics:")
print(f"  Mean Absolute Error (MAE): {mae:.4f} mm")
print(f"  Root Mean Square Error (RMSE): {rmse:.4f} mm")
print(f"  R² Score: {r_squared:.4f} (>1=excellent, 1=perfect, 0=mean baseline, <0=worse than mean)")
print(f"  Mean Absolute Percentage Error (MAPE): {mape:.4f}%")
print(f"  Mean Actual Rainfall: {np.mean(actual_values):.4f} mm")
print(f"  Std Dev Actual: {np.std(actual_values):.4f} mm")
print("="*70)

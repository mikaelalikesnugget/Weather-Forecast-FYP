import pandas as pd
import glob

# 1. Find all CSV files in the folder
cdf = pd.read_csv('Admiralty_Cleaned.csv')
df1 = pd.read_csv('AMK_Cleaned.csv')
df2 = pd.read_csv('Changi_Cleaned.csv')
df3 = pd.read_csv('Sentosa_Cleaned.csv')
df4 = pd.read_csv('TuasSouth_Cleaned.csv') # Looks for all CSV files in the same folder

combi = pd.concat([cdf, df1, df2, df3, df4], ignore_index=True)


# 4. Save to a new combined CSV
combi.to_csv("combined_weather.csv", index=False)

print("✅ Combined CSV saved as 'combined_weather.csv'")

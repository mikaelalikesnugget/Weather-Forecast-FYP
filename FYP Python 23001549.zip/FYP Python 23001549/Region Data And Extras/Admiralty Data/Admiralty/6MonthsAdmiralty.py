import pandas as pd
import numpy as np

# === 1. Load all 6 months ===
df = pd.read_csv('Admiralty April.csv')
df1 = pd.read_csv('Admiralty May.csv')
df2 = pd.read_csv('Admiralty June.csv')
df3 = pd.read_csv('Admiralty July.csv')
df4 = pd.read_csv('Admiralty Aug.csv')
df5 = pd.read_csv('Admiralty Sept.csv')

# === 2. Combine into one DataFrame ===
combiAdmiralty = pd.concat([df, df1, df2, df3, df4, df5], ignore_index=True)

# === 3. Clean up bad/missing values ===
# Replace '-' with 0 (since your dataset uses 0 and '-' for missing)
combiAdmiralty.replace('-', 0, inplace=True)

# === 4. Create proper Date column ===
combiAdmiralty["Date"] = pd.to_datetime(
    combiAdmiralty[["Year", "Month", "Day"]], errors="coerce"
)
# Drop year, month, day columns
combiAdmiralty.drop(columns=["Year", "Month", "Day"], inplace=True, errors="ignore")

# Move 'Date' to second column
date_col = combiAdmiralty.pop("Date")
combiAdmiralty.insert(1, "Date", date_col)

# === 5. Convert Date column correctly (for further grouping) ===
combiAdmiralty["Date"] = pd.to_datetime(combiAdmiralty["Date"], format="%Y-%m-%d", errors="coerce")

# === 6. Identify columns that need filling ===
target_cols = [col for col in combiAdmiralty.columns if "Temperature" in col or "Wind" in col]

# === 7. Ensure numeric type ===
for col in target_cols:
    combiAdmiralty[col] = pd.to_numeric(combiAdmiralty[col], errors="coerce")

# === 8. Create month-year period for grouping ===
combiAdmiralty["MonthPeriod"] = combiAdmiralty["Date"].dt.to_period("M")

# === 9. Fill 0s with monthly mean (ignoring zeros in mean calculation) ===
for col in target_cols:
    combiAdmiralty[col] = combiAdmiralty.groupby("MonthPeriod")[col].transform(
        lambda x: x.replace(0, np.nan).fillna(x[x != 0].mean())
    )

# === 10. Round filled values to 1 decimal place ===
combiAdmiralty[target_cols] = combiAdmiralty[target_cols].round(1)

# === 11. Remove 'Unnamed' columns using pop ===
for col in list(combiAdmiralty.columns):  # use list() to avoid runtime modification issues
    if col.startswith("Unnamed"):
        combiAdmiralty.pop(col)

# === 12. Drop helper column ===
combiAdmiralty.drop(columns="MonthPeriod", inplace=True)

# === 13. Save clean dataset ===
combiAdmiralty.to_csv("Admiralty_Filled.csv", index=False)



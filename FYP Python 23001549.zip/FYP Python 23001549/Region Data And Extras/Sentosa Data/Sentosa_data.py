import pandas as pd
import numpy as np

# === 1. Load all 6 months ===
df = pd.read_csv('Sentosa April.csv')
df1 = pd.read_csv('Sentosa May.csv')
df2 = pd.read_csv('Sentosa June.csv')
df3 = pd.read_csv('Sentosa July.csv')
df4 = pd.read_csv('Sentosa Aug.csv')
df5 = pd.read_csv('Sentosa Sept.csv')

# === 2. Combine into one DataFrame ===
combiSentosa = pd.concat([df, df1, df2, df3, df4, df5], ignore_index=True)

# === 3. Clean up bad/missing values ===
# Replace '-' with 0 (since your dataset uses 0 and '-' for missing)
combiSentosa.replace('-', 0, inplace=True)

# === 4. Create proper Date column ===
combiSentosa["Date"] = pd.to_datetime(
    combiSentosa[["Year", "Month", "Day"]], errors="coerce"
)
# Drop year, month, day columns
combiSentosa.drop(columns=["Year", "Month", "Day"], inplace=True, errors="ignore")

# Move 'Date' to second column
date_col = combiSentosa.pop("Date")
combiSentosa.insert(1, "Date", date_col)

# === 5. Convert Date column correctly (for further grouping) ===
combiSentosa["Date"] = pd.to_datetime(combiSentosa["Date"], errors="coerce")

# === 6. Identify columns that need filling ===
target_cols = [col for col in combiSentosa.columns if "Temperature" in col or "Wind" in col]

# === 7. Ensure numeric type ===
for col in target_cols:
    combiSentosa[col] = pd.to_numeric(combiSentosa[col], errors="coerce")

# === 8. Create month-year period for grouping ===
combiSentosa["MonthPeriod"] = combiSentosa["Date"].dt.to_period("M")

# === 9. Fill 0s with monthly mean (ignoring zeros in mean calculation) ===
for col in target_cols:
    combiSentosa[col] = combiSentosa.groupby("MonthPeriod")[col].transform(
        lambda x: x.replace(0, np.nan).fillna(x[x != 0].mean())
    )

# === 10. Round filled values to 1 decimal place ===
combiSentosa[target_cols] = combiSentosa[target_cols].round(1)

# === 11. Remove 'Unnamed' columns using pop ===
for col in list(combiSentosa.columns):  # use list() to avoid runtime modification issues
    if col.startswith("Unnamed"):
        combiSentosa.pop(col)

# === 12. Drop helper column ===
combiSentosa.drop(columns="MonthPeriod", inplace=True)

# === 13. Filter dates from April to September 2025 ===
start_date = pd.Timestamp('2025-04-01')
end_date = pd.Timestamp('2025-09-30')
filtered = combiSentosa[(combiSentosa['Date'] >= start_date) & (combiSentosa['Date'] <= end_date)].copy()

# === 14. Extract day and month for sorting ===
filtered['Day'] = filtered['Date'].dt.day
filtered['Month'] = filtered['Date'].dt.month

# === 15. Sort by Day ascending, then Month ascending ===
filtered.sort_values(by=['Day', 'Month'], inplace=True)

# === 16. Format Date back to 'd/m/yyyy' string ===
filtered['Date'] = filtered['Date'].dt.day.astype(str) + '/' + \
                   filtered['Date'].dt.month.astype(str) + '/' + \
                   filtered['Date'].dt.year.astype(str)

# === 17. Drop helper columns ===
filtered.drop(columns=['Day', 'Month'], inplace=True)

# === 18. Save cleaned and sorted dataset ===
filtered.to_csv("Sentosa_Filled_Sorted.csv", index=False)

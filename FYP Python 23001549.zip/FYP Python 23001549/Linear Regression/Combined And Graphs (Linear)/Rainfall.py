import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("2NewCombined.csv")

# Convert Date column properly (day comes first)
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')

# Select only rainfall columns
rain_cols = [col for col in df.columns if 'Daily Rainfall Total' in col]

# Plot all stations' rainfall over time
plt.figure(figsize=(12,6))
for col in rain_cols:
    plt.plot(df['Date'], df[col], label=col.replace('Daily Rainfall Total (mm)_', ''))

plt.title("Daily Rainfall by Station (mm)")
plt.xlabel("Date")
plt.ylabel("Rainfall (mm)")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

# =========================================================
# IMPORTS
# =========================================================
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# =========================================================
# LOAD & CLEAN DATA
# =========================================================
df = pd.read_csv("2NewCombined.csv")

df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
df = df.dropna(subset=["Date"])
df = df.sort_values("Date")

# Rainfall columns
rainfall_cols = [
    "Daily Rainfall Total (mm)_Changi",
    "Daily Rainfall Total (mm)_Admiralty",
    "Daily Rainfall Total (mm)_Ang Mo Kio",
    "Daily Rainfall Total (mm)_Tuas South",
    "Daily Rainfall Total (mm)_Sentosa Island"
]

df[rainfall_cols] = df[rainfall_cols].apply(pd.to_numeric, errors="coerce").fillna(0)

# Use Singapore’s monsoon seasons
# NE Monsoon: Dec – early Mar
# Inter–Monsoon 1: Late Mar – May
# SW Monsoon: Jun – Sep
# Inter–Monsoon 2: Oct – Nov

# =========================================================
# FUNCTION TO ASSIGN MONSOON SEASON
# =========================================================
def get_monsoon(month):
    if month in [12, 1, 2, 3]:
        return "Northeast Monsoon (Dec–Mar)"
    elif month in [4, 5]:
        return "Inter-Monsoon 1 (Apr–May)"
    elif month in [6, 7, 8, 9]:
        return "Southwest Monsoon (Jun–Sep)"
    elif month in [10, 11]:
        return "Inter-Monsoon 2 (Oct–Nov)"
    return "Unknown"

df["Monsoon"] = df["Date"].dt.month.apply(get_monsoon)
df["Year"] = df["Date"].dt.year

# =========================================================
# TOTAL RAINFALL PER MONSOON (All Regions Combined)
# =========================================================
df["Total_Rainfall"] = df[rainfall_cols].sum(axis=1)

monsoon_totals = df.groupby("Monsoon")["Total_Rainfall"].mean().reindex([
    "Northeast Monsoon (Dec–Mar)",
    "Inter-Monsoon 1 (Apr–May)",
    "Southwest Monsoon (Jun–Sep)",
    "Inter-Monsoon 2 (Oct–Nov)"
])

plt.figure(figsize=(10,6))
monsoon_totals.plot(kind="bar")
plt.title("Average Rainfall by Monsoon Season")
plt.ylabel("Average Daily Rainfall (mm)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# =========================================================
# YEARLY TREND: WHICH MONSOON GETS WETTER?
# =========================================================
yearly_monsoon = df.groupby(["Year", "Monsoon"])["Total_Rainfall"].mean().unstack()

yearly_monsoon.plot(figsize=(14,6))
plt.title("Rainfall Trend Across Monsoon Seasons Over the Years")
plt.ylabel("Average Daily Rainfall (mm)")
plt.xlabel("Year")
plt.legend(title="Monsoon Season")
plt.grid(True)
plt.show()

# =========================================================
# REGION-LEVEL MONSOON ANALYSIS (North/South/etc)
# =========================================================
df["North"]   = df["Daily Rainfall Total (mm)_Admiralty"]
df["Central"] = df["Daily Rainfall Total (mm)_Ang Mo Kio"]
df["East"]    = df["Daily Rainfall Total (mm)_Changi"]
df["West"]    = df["Daily Rainfall Total (mm)_Tuas South"]
df["South"]   = df["Daily Rainfall Total (mm)_Sentosa Island"]

region_cols = ["North", "Central", "East", "West", "South"]

monsoon_region = df.groupby("Monsoon")[region_cols].mean().reindex([
    "Northeast Monsoon (Dec–Mar)",
    "Inter-Monsoon 1 (Apr–May)",
    "Southwest Monsoon (Jun–Sep)",
    "Inter-Monsoon 2 (Oct–Nov)"
])

plt.figure(figsize=(12,7))
sns.heatmap(monsoon_region, annot=True, cmap="Blues")
plt.title("Regional Rainfall Pattern by Monsoon Season")
plt.xlabel("Region")
plt.ylabel("Monsoon Season")
plt.tight_layout()
plt.show()

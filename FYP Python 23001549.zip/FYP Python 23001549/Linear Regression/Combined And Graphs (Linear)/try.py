import sys
sys.path.append(r"C:\Users\23001549\OneDrive - Republic Polytechnic\Documents\FYP PYTHON")
print(sys.path)


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
# Step 1: Import libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# Step 2: Load dataset
df = pd.read_csv("2NewCombined.csv")  # replace with your CSV file path

# Step 3: Select features (X) and target (y)
# Example: predict rainfall at Changi
target_column = "Daily Rainfall Total (mm)_Sentosa Island"
feature_columns = df.columns.drop(["Date", target_column])  # use all other columns except Date and target

X = df[feature_columns]
y = df[target_column]

# Step 4: Handle missing values (optional)
X = X.fillna(0)
y = y.fillna(0)

# Step 5: Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Train a model
model = LinearRegression()
model.fit(X_train, y_train)

# Step 7: Make predictions
y_pred = model.predict(X_test)

# Step 8: Compare actual vs predicted
results = pd.DataFrame({
    "Actual": y_test,
    "Predicted": y_pred
})

print(results)

# Step 9: Evaluate model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Mean Squared Error: {mse:.2f}")
print(f"R^2 Score: {r2:.2f}")

# Step 10: Visualize actual vs predicted
plt.figure(figsize=(10,6))
plt.plot(y_test.values, label="Actual", marker='o')
plt.plot(y_pred, label="Predicted", marker='x')
plt.xlabel("Samples")
plt.ylabel("Rainfall (mm)")
plt.title("Actual vs Predicted Rainfall at Sentosa")
plt.legend()
plt.show()

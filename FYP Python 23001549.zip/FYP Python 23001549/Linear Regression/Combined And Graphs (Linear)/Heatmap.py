# =========================================================
# IMPORTS
# =========================================================
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# =========================================================
# LOAD DATA
# =========================================================
df = pd.read_csv("2NewCombined.csv")

# --- FIX DATE COLUMN ---
df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
df = df.dropna(subset=["Date"])      # remove rows with invalid dates
df = df.sort_values("Date")          # safe sorting

# =========================================================
# RAINFALL COLUMNS
# =========================================================
rainfall_cols = [
    "Daily Rainfall Total (mm)_Changi",
    "Daily Rainfall Total (mm)_Admiralty",
    "Daily Rainfall Total (mm)_Ang Mo Kio",
    "Daily Rainfall Total (mm)_Tuas South",
    "Daily Rainfall Total (mm)_Sentosa Island"
]

# Ensure rainfall values are numeric
df[rainfall_cols] = df[rainfall_cols].apply(pd.to_numeric, errors="coerce").fillna(0)

# =========================================================
# REGION GROUPING (East / North / Central / West / South)
# =========================================================
df["East"]   = df["Daily Rainfall Total (mm)_Changi"]
df["North"]  = df["Daily Rainfall Total (mm)_Admiralty"]
df["Central"]= df["Daily Rainfall Total (mm)_Ang Mo Kio"]
df["West"]   = df["Daily Rainfall Total (mm)_Tuas South"]
df["South"]  = df["Daily Rainfall Total (mm)_Sentosa Island"]

region_groups = ["East", "North", "Central", "West", "South"]

# =========================================================
# REGION TREND PLOTS
# =========================================================
df.set_index("Date")[region_groups].plot(figsize=(14,6))
plt.title("Regional Rainfall Comparison (East, North, Central, West, South)")
plt.ylabel("Rainfall (mm)")
plt.xlabel("Date")
plt.show()

# =========================================================
# CORRELATION HEATMAP
# =========================================================
plt.figure(figsize=(10,7))
sns.heatmap(df[rainfall_cols].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Between Rainfall Stations")
plt.show()

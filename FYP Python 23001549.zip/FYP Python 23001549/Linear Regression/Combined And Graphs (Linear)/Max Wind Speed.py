import pandas as pd
import matplotlib.pyplot as plt

# === 1. Load the dataset ===
df = pd.read_csv("2NewCombined.csv")

# === 2. Convert Date column to datetime ===
# Your dates are in day/month/year format
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')

# === 3. Select all columns containing 'Max Wind Speed' ===
wind_cols = [col for col in df.columns if 'Max Wind Speed' in col]

# === 4. Plot each station’s wind speed ===
plt.figure(figsize=(12, 6))
for col in wind_cols:
    plt.plot(df['Date'], df[col], label=col.replace('Max Wind Speed (km/h)_', ''))

plt.title("Maximum Wind Speed by Station (km/h)")
plt.xlabel("Date")
plt.ylabel("Wind Speed (km/h)")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

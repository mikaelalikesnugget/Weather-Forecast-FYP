import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from scipy.stats import linregress
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt

# Set seeds for reproducibility
tf.random.set_seed(42)
np.random.seed(42)

# 1. LOAD & CLEAN
df = pd.read_csv('2NewCombined.csv')

# Focus on Ang Mo Kio (AMK)
amk_cols = [col for col in df.columns if 'Ang Mo Kio' in col]
df_amk = df[amk_cols].copy()
target_col = 'Daily Rainfall Total (mm)_Ang Mo Kio'
df_amk.rename(columns={target_col: 'Rainfall_amk'}, inplace=True)

# 2. FEATURE ENGINEERING (To boost R^2)
# Add 1-day lag: Yesterday's weather helps predict today
for col in df_amk.columns:
    df_amk[f'{col}_lag1'] = df_amk[col].shift(1)

# Add a 3-day rolling average for rainfall (captures wet/dry spells)
df_amk['Rain_Roll3'] = df_amk['Rainfall_amk'].shift(1).rolling(window=3).mean()

# Drop rows with NaN from shifting/rolling
df_amk = df_amk.dropna()

# 3. SPLIT 
SPLIT = 0.80
split_idx = int(len(df_amk) * SPLIT)
train_df = df_amk.iloc[:split_idx]
test_df = df_amk.iloc[split_idx:]

# 4. SCALING (Preventing Leakage)
scaler_x = StandardScaler()
scaler_y = StandardScaler()

X_train_scaled = scaler_x.fit_transform(train_df)
X_test_scaled = scaler_x.transform(test_df)

scaler_y.fit(train_df[['Rainfall_amk']])
y_train_scaled = scaler_y.transform(train_df[['Rainfall_amk']])
y_test_scaled = scaler_y.transform(test_df[['Rainfall_amk']])

# 5. WINDOWING (Teacher recommended < 10 days)
def create_sequences(X, y, window):
    Xs, ys = [], []
    for i in range(len(X) - window):
        Xs.append(X[i:(i + window)])
        ys.append(y[i + window])
    return np.array(Xs), np.array(ys)

WINDOW = 7 # Using 7 days as a balanced window
X_train, y_train = create_sequences(X_train_scaled, y_train_scaled, WINDOW)
X_test, y_test = create_sequences(X_test_scaled, y_test_scaled, WINDOW)

# 6. MODEL (Using GRU for better performance on small data)
model = keras.Sequential([
    keras.layers.GRU(64, activation='relu', input_shape=(X_train.shape[1], X_train.shape[2])),
    keras.layers.Dense(32, activation='relu'),
    keras.layers.Dropout(0.1),
    keras.layers.Dense(1)
])

model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.001), loss='mse')

# 7. TRAINING
early_stop = keras.callbacks.EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True)
model.fit(X_train, y_train, epochs=150, batch_size=8, validation_split=0.1, callbacks=[early_stop], verbose=0)

# 8. PREDICTIONS & EVALUATION
pred_scaled = model.predict(X_test)
predicted = scaler_y.inverse_transform(pred_scaled).flatten()
actual = scaler_y.inverse_transform(y_test).flatten()

# Rainfall cannot be negative
predicted = np.maximum(predicted, 0)

# Calculate Stats
r2 = r2_score(actual, predicted)
mae = mean_absolute_error(actual, predicted)
rmse = np.sqrt(mean_squared_error(actual, predicted))
slope, intercept, r_val, p_val, std_err = linregress(actual, predicted)

print(f"--- Metrics ---")
print(f"R2 Score: {r2:.4f}")
print(f"MAE: {mae:.4f} mm")
print(f"RMSE: {rmse:.4f} mm")
print(f"P-Value: {p_val:.6f}")

# 9. PLOT RESULTS
plt.figure(figsize=(12, 6))
plt.plot(actual, label='Actual Rainfall (AMK)', color='blue', marker='o')
plt.plot(predicted, label='Predicted Rainfall (AMK)', color='red', linestyle='--', marker='x')
plt.title(f"AMK Rainfall Prediction\n(R2: {r2:.2f}, P-Value: {p_val:.4f})")
plt.xlabel("Days (Test Set)")
plt.ylabel("Rainfall (mm)")
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()
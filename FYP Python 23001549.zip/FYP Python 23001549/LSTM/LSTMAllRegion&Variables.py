import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import ttest_rel

import matplotlib.pyplot as plt

# ---------------------------
# SEED
# ---------------------------
tf.random.set_seed(99)
np.random.seed(99)

# ---------------------------
# LOAD DATA
# ---------------------------
CSV_PATH = "2NewCombined.csv"   # change if needed
df = pd.read_csv(CSV_PATH)

# ---------------------------
# DEFINE TARGETS (RAIN TOTAL)
# ---------------------------
target_map = {
    "Daily Rainfall Total (mm)_Admiralty": "Rain_admiralty",
    "Daily Rainfall Total (mm)_Ang Mo Kio": "Rain_amk",
    "Daily Rainfall Total (mm)_Changi": "Rain_changi",
    "Daily Rainfall Total (mm)_Sentosa Island": "Rain_sentosa",
    "Daily Rainfall Total (mm)_Tuas South": "Rain_tuas",
}

df = df.rename(columns=target_map)

TARGETS = list(target_map.values())

# ---------------------------
# HANDLE DATE (optional but recommended for sorting)
# ---------------------------
if "Date" in df.columns:
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.sort_values("Date")
    df = df.drop(columns=["Date"])

# ---------------------------
# FEATURES = all numeric columns
# (this includes temp + wind + rainfall intensity etc.)
# ---------------------------
# Keep only numeric columns
df = df.select_dtypes(include=[np.number]).copy()

# Safety check: ensure targets exist
missing_targets = [c for c in TARGETS if c not in df.columns]
if missing_targets:
    raise ValueError(f"Missing target columns after renaming: {missing_targets}")

FEATURES = df.columns.tolist()  # all numeric columns

# ---------------------------
# IMPUTE MISSING VALUES
# ---------------------------
imputer = SimpleImputer(strategy="median")
df_imputed = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)

# ---------------------------
# SCALE FEATURES (X) and TARGETS (y) separately
# ---------------------------
X_scaler = MinMaxScaler()
y_scaler = MinMaxScaler()

X_scaled = pd.DataFrame(X_scaler.fit_transform(df_imputed[FEATURES]), columns=FEATURES)
y_scaled = pd.DataFrame(y_scaler.fit_transform(df_imputed[TARGETS]), columns=TARGETS)

# Combine so windowing is easy
scaled_all = X_scaled.copy()
# (Targets are also part of FEATURES, that’s fine; we still scale y separately for clean inverse_transform)
# But we overwrite the target columns with y scaling (so y inverse is correct):
scaled_all[TARGETS] = y_scaled[TARGETS]

# ---------------------------
# WINDOWING (X uses all FEATURES, y uses TARGETS only)
# ---------------------------
def make_windows(data_df, feature_cols, target_cols, window):
    X, y = [], []
    values = data_df[feature_cols].values
    target_values = data_df[target_cols].values

    for i in range(len(data_df) - window):
        X.append(values[i:i+window])        # (window, num_features)
        y.append(target_values[i+window])   # (num_targets,)
    return np.array(X), np.array(y)

WINDOW = 20
X, y = make_windows(scaled_all, FEATURES, TARGETS, WINDOW)

# ---------------------------
# TRAIN/TEST SPLIT (time-based)
# ---------------------------
SPLIT = 0.85
split_idx = int(len(X) * SPLIT)

X_train, X_test = X[:split_idx], X[split_idx:]
y_train, y_test = y[:split_idx], y[split_idx:]

# ---------------------------
# LSTM MODEL
# ---------------------------
model = keras.Sequential([
    keras.layers.Input(shape=(WINDOW, X_train.shape[2])),
    keras.layers.LSTM(128),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(len(TARGETS))
])

model.compile(optimizer="adam", loss="mse", metrics=["mae"])
model.summary()

history = model.fit(
    X_train, y_train,
    epochs=20,
    batch_size=32,
    validation_split=0.1,
    verbose=1
)

# ---------------------------
# PREDICT + INVERSE TRANSFORM (targets only)
# ---------------------------
y_pred_scaled = model.predict(X_test)

y_pred = y_scaler.inverse_transform(y_pred_scaled)
y_true = y_scaler.inverse_transform(y_test)

# ---------------------------
# METRICS + P-VALUE
# ---------------------------
print("\nMODEL EVALUATION (Test Set)\n")

for i, name in enumerate(TARGETS):
    actual = y_true[:, i]
    pred = y_pred[:, i]

    mae = mean_absolute_error(actual, pred)
    rmse = np.sqrt(mean_squared_error(actual, pred))
    r2 = r2_score(actual, pred)

    # Safe MAPE when actual has zeros
    mape = np.mean(np.abs((actual - pred) / np.maximum(np.abs(actual), 1e-6))) * 100

    # Paired t-test: actual vs predicted
    t_stat, p_val = ttest_rel(actual, pred)

    print(f"{name}")
    print(f"  MAE   : {mae:.3f}")
    print(f"  RMSE  : {rmse:.3f}")
    print(f"  MAPE  : {mape:.2f}%")
    print(f"  R^2   : {r2:.3f}")
    print(f"  p-val : {p_val:.4f}")
    print("-" * 35)

# ---------------------------
# CLEAR PLOTS (one target per figure)
# ---------------------------
for i, name in enumerate(TARGETS):
    plt.figure(figsize=(10, 4))
    plt.plot(y_true[:, i], label="Actual", linewidth=2)
    plt.plot(y_pred[:, i], label="Predicted", linestyle="--")
    plt.title(f"Rainfall Forecast (LSTM + Temp/Wind Features) - {name}")
    plt.xlabel("Time (Test Samples)")
    plt.ylabel("Rainfall (mm)")
    plt.legend()
    plt.tight_layout()
    plt.show()
